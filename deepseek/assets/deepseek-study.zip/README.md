# DeepSeek component study

This archive contains weighted pooling and analytic global-cache accounting, not a complete DeepSeek model. Requires Python and PyTorch.

Run from this directory:

    python -m unittest discover -s tests -v
    python experiments/initial_study.py

No model weights, training run or GPU are required. See the results file for source and implementation hashes, environment and scope.
