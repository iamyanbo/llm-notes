import json
from pathlib import Path
import unittest
import torch
from torch.autograd import gradcheck
from deepseek_study.compression import pool_complete_blocks, stream_pool, completed_block_mask
from deepseek_study.cache_accounting import packed_entry_bytes, v41_global_cache

ROOT = Path(__file__).resolve().parents[1]


class CompressionTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        torch.set_num_threads(1)

    def test_channelwise_pooling_against_scalar_definition(self):
        v, s = torch.randn(2, 11, 3, dtype=torch.double), torch.randn(2, 11, 3, dtype=torch.double)
        expected = torch.empty(2, 3, 3, dtype=torch.double)
        for b in range(2):
            for group in range(3):
                for channel in range(3):
                    scores = s[b, 3 * group:3 * group + 3, channel]
                    p = (scores - scores.max()).exp()
                    p = p / p.sum()
                    expected[b, group, channel] = (p * v[b, 3 * group:3 * group + 3, channel]).sum()
        torch.testing.assert_close(pool_complete_blocks(v, s, 3), expected)

    def test_streaming_all_two_chunk_boundaries(self):
        for ratio in (1, 2, 4):
            v, s = torch.randn(2, 13, 5), torch.randn(2, 13, 5)
            expected = pool_complete_blocks(v, s, ratio)
            for split in range(14):
                a, state = stream_pool(v[:, :split], s[:, :split], ratio)
                b, state = stream_pool(v[:, split:], s[:, split:], ratio, state)
                torch.testing.assert_close(torch.cat([a, b], dim=1), expected)
                self.assertEqual(state.tokens_seen, 13)
                self.assertEqual(state.values.shape[1], 13 % ratio)

    def test_incomplete_group_emits_nothing(self):
        v, s = torch.randn(1, 3, 2), torch.randn(1, 3, 2)
        out, state = stream_pool(v, s, 4)
        self.assertEqual(out.shape, (1, 0, 2))
        self.assertEqual(state.values.shape, (1, 3, 2))

    def test_no_future_dependency_for_any_query(self):
        v, s = torch.randn(1, 15, 3), torch.randn(1, 15, 3)
        original = pool_complete_blocks(v, s, 2)
        for t in range(15):
            changed_v, changed_s = v.clone(), s.clone()
            changed_v[:, t + 1:] += 100
            changed_s[:, t + 1:] -= 100
            visible = completed_block_mask(torch.tensor(t), original.shape[1], 2)
            changed = pool_complete_blocks(changed_v, changed_s, 2)
            torch.testing.assert_close(original[:, visible], changed[:, visible])

    def test_visibility_at_completion(self):
        mask = completed_block_mask(torch.arange(5), 3, 2)
        self.assertEqual(mask.tolist(), [[False, False, False], [True, False, False],
                                         [True, False, False], [True, True, False],
                                         [True, True, False]])

    def test_gradients_and_cross_chunk_gradients(self):
        v = torch.randn(1, 4, 2, dtype=torch.double, requires_grad=True)
        s = torch.randn(1, 4, 2, dtype=torch.double, requires_grad=True)
        self.assertTrue(gradcheck(lambda a, b: pool_complete_blocks(a, b, 2), (v, s)))
        expected = torch.autograd.grad(pool_complete_blocks(v, s, 2).square().sum(), (v, s))
        a, state = stream_pool(v[:, :1], s[:, :1], 2)
        b, state = stream_pool(v[:, 1:], s[:, 1:], 2, state)
        actual = torch.autograd.grad(torch.cat([a, b], dim=1).square().sum(), (v, s))
        for x, y in zip(actual, expected):
            torch.testing.assert_close(x, y)

    def test_ratio_one_identity_and_invalid_shapes(self):
        v, s = torch.randn(1, 4, 2), torch.randn(1, 4, 2)
        torch.testing.assert_close(pool_complete_blocks(v, s, 1), v)
        with self.assertRaises(ValueError):
            pool_complete_blocks(v, s[:, :2], 2)
        with self.assertRaises(ValueError):
            pool_complete_blocks(v, s, 0)
        _, state = stream_pool(v[:, :1], s[:, :1], 2)
        with self.assertRaises(ValueError):
            stream_pool(v, s, 4, state)


class CacheAccountingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.config = json.loads((ROOT / 'configs/v41-reference.json').read_text())

    def test_reported_slope_from_independent_storage_terms(self):
        self.assertEqual(packed_entry_bytes(512, 4, 16), 288)
        self.assertEqual(packed_entry_bytes(128, 4, 32), 68)
        result = v41_global_cache(self.config, 1_000_000)
        self.assertEqual(result['asymptotic_bytes_per_token'], 890)
        self.assertEqual(result['total_bytes'], 890_000_000)
        self.assertEqual(result['owner_count'], 4)

    def test_sharing_and_precision_counterfactuals(self):
        unshared = v41_global_cache(self.config, 1024, share_layers=False)
        self.assertEqual(unshared['owner_count'], 38)
        self.assertEqual(unshared['asymptotic_bytes_per_token'], 10324)
        fp8 = v41_global_cache(self.config, 1024, main_bits=8)
        self.assertEqual(fp8['asymptotic_bytes_per_token'], 1530)

    def test_incomplete_entry_is_not_charged_as_complete(self):
        r = v41_global_cache(self.config, 3)
        # Three encoder owners each have one completed pair; decoder has three entries.
        self.assertEqual(r['total_bytes'], 6 * (288 + 68))
        self.assertEqual(v41_global_cache(self.config, 0)['total_bytes'], 0)


if __name__ == '__main__':
    unittest.main()
