"""Run the initial CPU-only correctness/accounting study. No training or timing claims."""
import json
import hashlib
from pathlib import Path
import platform
import sys
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from deepseek_study.cache_accounting import v41_global_cache
from deepseek_study.compression import pool_complete_blocks, stream_pool


def main():
    torch.set_num_threads(1)
    torch.manual_seed(20261016)
    config = json.loads((ROOT / 'configs/v41-reference.json').read_text())
    cases = []
    with torch.no_grad():
        for ratio in (1, 2, 4):
            v, s = torch.randn(2, 129, 16), torch.randn(2, 129, 16)
            expected = pool_complete_blocks(v, s, ratio)
            state, outputs = None, []
            for lo, hi in [(0, 17), (17, 70), (70, 128), (128, 129)]:
                y, state = stream_pool(v[:, lo:hi], s[:, lo:hi], ratio, state)
                outputs.append(y)
            actual = torch.cat(outputs, dim=1)
            cases.append({'ratio': ratio, 'shape': list(actual.shape),
                          'max_abs_streaming_error': (actual - expected).abs().max().item(),
                          'pending_tokens': state.values.shape[1]})
    result = {
        'status': 'component study only; no full architecture or trained-model reproduction',
        'python': platform.python_version(), 'torch': torch.__version__, 'device': 'cpu',
        'seed': 20261016, 'threads': 1,
        'source_manifest': 'sources.lock.json',
        'source_manifest_sha256': hashlib.sha256((ROOT / 'sources.lock.json').read_bytes()).hexdigest(),
        'implementation_sha256': {
            name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
            for name in ('deepseek_study/compression.py', 'deepseek_study/cache_accounting.py',
                         'experiments/initial_study.py')
        },
        'streaming_pooling': cases,
        'packed_global_cache': v41_global_cache(config, 1_000_000),
        'counterfactuals': {
            'disable_layer_sharing_keep_formats': v41_global_cache(config, 1_000_000, share_layers=False),
            'main_fp8_keep_sharing_and_scale_granularity': v41_global_cache(config, 1_000_000, main_bits=8),
        },
        'limitations': [
            'Cache bytes are analytic, not measured VRAM; excludes local SWA and temporary state.',
            'Pooling core excludes learned projections, RMSNorm, RoPE, quantization and attention.',
            'Counterfactuals are storage calculations, not alternative trained models or V4 baselines.',
            'No latency, downstream accuracy or training convergence was measured.',
        ],
    }
    target = ROOT / 'results/initial-study.json'
    target.parent.mkdir(exist_ok=True)
    target.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'result': str(target), 'streaming_pooling': cases,
                      'global_cache_bytes_per_token': result['packed_global_cache']['asymptotic_bytes_per_token']}, indent=2))


if __name__ == '__main__':
    main()
