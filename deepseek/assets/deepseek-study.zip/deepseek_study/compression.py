"""CSA2's weighted pooling core, before RMSNorm, RoPE and quantization.

Inputs are already projected values and gates, shaped [batch, tokens, channels].
This is not the complete Compressor or attention layer. Unlike the upstream
prefill-then-single-token interface, the streaming wrapper accepts arbitrary chunks.
"""
from dataclasses import dataclass
import torch


def _validate(values, scores, ratio):
    if isinstance(ratio, bool) or not isinstance(ratio, int) or ratio < 1:
        raise ValueError("ratio must be a positive integer")
    if values.ndim != 3 or scores.shape != values.shape:
        raise ValueError("values and scores must have matching [B, T, D] shapes")
    if not values.is_floating_point() or not scores.is_floating_point():
        raise ValueError("values and scores must be floating point")
    if values.device != scores.device or values.dtype != scores.dtype:
        raise ValueError("values and scores must share device and dtype")


def pool_complete_blocks(values, scores, ratio):
    """Pool completed blocks only; callers retain an incomplete suffix separately.

    Softmax is over tokens within each block, independently for every channel.
    Float64 is preserved for gradient checks; fp16/bf16 pooling accumulates in fp32.
    """
    _validate(values, scores, ratio)
    batch, length, width = values.shape
    blocks = length // ratio
    if not blocks:
        return values[:, :0, :]
    dtype = torch.float64 if values.dtype == torch.float64 else torch.float32
    v = values[:, :blocks * ratio].to(dtype).reshape(batch, blocks, ratio, width)
    s = scores[:, :blocks * ratio].to(dtype).reshape(batch, blocks, ratio, width)
    return (v * s.softmax(dim=2)).sum(dim=2).to(values.dtype)


@dataclass
class PoolState:
    values: torch.Tensor
    scores: torch.Tensor
    tokens_seen: int
    ratio: int


def stream_pool(values, scores, ratio, state=None):
    """Functional streaming state; use separate states for separate sequences.

    The state keeps the autograd graph. In inference, call under no_grad(); do not
    detach here, since training across a chunk boundary needs those dependencies.
    """
    _validate(values, scores, ratio)
    seen = 0
    if state is not None:
        if (state.ratio != ratio
                or state.values.shape[0] != values.shape[0]
                or state.values.shape[2] != values.shape[2]
                or state.values.dtype != values.dtype
                or state.values.device != values.device
                or state.values.shape != state.scores.shape
                or state.scores.dtype != scores.dtype
                or state.scores.device != scores.device
                or state.values.shape[1] != state.tokens_seen % ratio):
            raise ValueError("state is incompatible with this stream")
        seen = state.tokens_seen
        joined_v = torch.cat([state.values, values], dim=1)
        joined_s = torch.cat([state.scores, scores], dim=1)
    else:
        joined_v, joined_s = values, scores
    output = pool_complete_blocks(joined_v, joined_s, ratio)
    cutoff = (joined_v.shape[1] // ratio) * ratio
    # Clone a small suffix so its view does not retain an entire prefill allocation.
    next_state = PoolState(joined_v[:, cutoff:].clone(), joined_s[:, cutoff:].clone(),
                           seen + values.shape[1], ratio)
    return output, next_state


def completed_block_mask(query_positions, block_count, ratio):
    """Visibility for zero-based token positions: (block+1)*ratio <= query+1.

    This matches the pinned V4.1 indexer's prefill compress_lens convention.
    It is not a full sparse attention mask (local windows, sinks and Top-K are absent).
    """
    if ratio < 1 or block_count < 0:
        raise ValueError("invalid ratio or block count")
    ends_exclusive = (torch.arange(block_count, device=query_positions.device) + 1) * ratio
    return ends_exclusive <= query_positions[..., None] + 1
