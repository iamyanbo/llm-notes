"""Small, explicitly scoped reference implementations for the DeepSeek study."""
