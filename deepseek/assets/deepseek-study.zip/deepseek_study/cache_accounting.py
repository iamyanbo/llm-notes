"""Analytic packed global-cache accounting, not measured runtime allocation."""
from fractions import Fraction
from math import ceil


def packed_entry_bytes(channels, value_bits, scale_group, scale_bytes=1):
    if channels < 1 or value_bits < 1 or scale_group < 1 or scale_bytes < 0:
        raise ValueError("invalid storage format")
    return ceil(channels * value_bits / 8) + ceil(channels / scale_group) * scale_bytes


def v41_global_cache(config, sequence_length, *, share_layers=True, main_bits=4):
    """Keep index keys FP4/32 and main scales one byte/16 in all counterfactuals.

    Includes main KV + indexer K at KV-owner layers only. Excludes SWA, partial
    groups, temporary indices, weights, allocator padding and workspace. Sequence
    length controls completed entry counts; bytes/token is the asymptotic slope.
    """
    if sequence_length < 0:
        raise ValueError("sequence length must be nonnegative")
    layers = config["n_layers"]
    ratios = config["compress_ratios"][:layers]
    owners = config["kv_source_layers"] if share_layers else [i for i, r in enumerate(ratios) if r]
    main = packed_entry_bytes(config["head_dim"], main_bits, 16)
    index = packed_entry_bytes(config["index_head_dim"], 4, 32)
    rows = []
    slope = Fraction(0)
    for layer in owners:
        ratio = ratios[layer]
        if ratio <= 0:
            raise ValueError("global cache owner must have a positive compression ratio")
        entries = sequence_length // ratio
        slope += Fraction(main + index, ratio)
        rows.append({"layer_zero_based": layer, "compression_ratio": ratio,
                     "entries": entries, "main_bytes": entries * main,
                     "index_bytes": entries * index})
    return {"scope": "analytic packed global main KV and indexer K only",
            "sequence_length": sequence_length, "owner_count": len(owners),
            "main_entry_bytes": main, "index_entry_bytes": index,
            "asymptotic_bytes_per_token": float(slope),
            "total_bytes": sum(r["main_bytes"] + r["index_bytes"] for r in rows),
            "owners": rows}
