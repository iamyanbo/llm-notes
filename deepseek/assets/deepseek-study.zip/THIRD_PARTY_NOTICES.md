# Third-party references

`configs/v41-reference.json` is copied without modification from DeepSeek-AI's DeepSeek-V4.1-Flash repository, revision `314113f8a7dadb388215396ba5fbee2c610a04d6`, file `inference/config.json`.

Source: https://huggingface.co/deepseek-ai/DeepSeek-V4.1-Flash/blob/314113f8a7dadb388215396ba5fbee2c610a04d6/inference/config.json

The upstream MIT license is retained in `configs/LICENSE.deepseek`.

Other upstream reference files are fetched into the ignored `reference_cache/` for reading. Their immutable URLs and hashes are in `sources.lock.json`. They are not imported or executed by the study. Research reports are linked rather than redistributed.
